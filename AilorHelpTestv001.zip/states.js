"use strict";

module.exports = {
    'FRESH_START': '_FRESH_START'
};